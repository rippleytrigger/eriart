
	<?php get_header(); ?>



		<?php get_template_part('templates/nav'); ?>


		<div class="container mt-40 mb-40" >
			
			<h1 class="text-center jumbotron"> Lo sentimos pero su búsqueda no fue encontrada. </h1>

		</div>

	<?php get_footer(); ?>
