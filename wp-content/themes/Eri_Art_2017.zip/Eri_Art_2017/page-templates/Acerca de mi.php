<?php
/*
	Template Name: Acerca de mi
*/


 get_header();


	get_template_part('templates/nav');

	?>

		<div class="container">

			<img class="img-responsive" src="http://localhost/word_/wp-content/uploads/2017/06/rock_it.jpg">
			

		</div>

<?php



 get_footer();


?>