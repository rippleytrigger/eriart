<?php

/*
	template Name: Contacto
*/

	get_header();
?>